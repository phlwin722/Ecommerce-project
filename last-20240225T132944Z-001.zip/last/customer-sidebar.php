<div class="user-sidebar">
    <ul>
    <a href="dashboard.php"><button class="btn btn-danger"><?php echo "Dashboard"; ?></button></a>
    <a href="customer-profile-update.php"><button class="btn btn-danger"><?php echo "Profile"; ?></button></a>
        <a href="customer-billing-shipping-update.php"><button class="btn btn-danger"><?php echo "Update Shipping Info"; ?></button></a>
        <a href="customer-password-update.php"><button class="btn btn-danger"><?php echo "Update Password"; ?></button></a>
        <a href="customer-order.php"><button class="btn btn-danger"><?php echo "Order Details"; ?></button></a>
        <a href="view_dates_ship.php"><button class="btn btn-danger"><?php echo "Order Status"; ?></button></a>
        <a href="int.php"><button class="btn btn-danger"><?php echo "Send you Design now"; ?></button></a>
        <a href="logout.php"><button class="btn btn-danger"><?php echo "Log out"; ?></button></a>
       
    </ul>
</div>
